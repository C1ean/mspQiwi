<?php

$_lang['area_mspqiwi'] = "Qiwi";

$_lang['setting_ms2_mspqiwi_url'] = 'URL сервиса';
$_lang['setting_ms2_mspqiwi_url_desc'] = 'Адрес скрипта на стороне Qiwi';


$_lang['setting_ms2_mspqiwi_shopId'] = 'Логин';
$_lang['setting_ms2_mspqiwi_shopId_desc'] = 'ISHOPID киви';


$_lang['setting_ms2_mspqiwi_shopKey'] = 'Пароль киви';
$_lang['setting_ms2_mspqiwi_shopKey_desc'] = 'Пароль к ЛК киви';


$_lang['setting_ms2_mspqiwi_lifetime'] = 'Время жизни счета';
$_lang['setting_ms2_mspqiwi_lifetime_desc'] = 'Время жизни выставленного счета';


$_lang['setting_ms2_mspqiwi_check_agt'] = 'Проверять агента Qiwi';
$_lang['setting_ms2_mspqiwi_check_agt_desc'] = 'Проверяет есть ли указанный клиент в киви банке.';


$_lang['setting_ms2_mspqiwi_comment'] = 'Комментарий';
$_lang['setting_ms2_mspqiwi_comment_desc'] = 'Комментарий для платежа в Qiwi.Цепляется к выставленному счету внутри Qiwi';

$_lang['setting_ms2_mspqiwi_successId'] = 'Страница успшеной оплаты Qiwi';
$_lang['setting_ms2_mspqiwi_successId_desc'] = 'ID страницы куда направить пользователя после успешной оплаты покупки';

$_lang['setting_ms2_mspqiwi_failureId'] = 'Страница отказа от оплаты Qiwi';
$_lang['setting_ms2_mspqiwi_failureId_desc'] = 'ID страницы куда направить пользователя в случае отказа от оплаты покупки';

$_lang['setting_ms2_mspqiwi_currency'] = 'Код валюты';
$_lang['setting_ms2_mspqiwi_currency_desc'] = 'Код валюты для оплаты. По умолчанию 643 (рубли),согласно спеке. Qiwi';





